from evaluacionestudiantes.ui.consola import UiConsola

if __name__ == "__main__":
    UiConsola().ejecutar()
